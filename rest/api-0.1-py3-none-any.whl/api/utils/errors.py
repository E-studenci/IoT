

class MongoConnectionError(ConnectionError):
    pass


class RedisConnectionError(ConnectionError):
    pass